<div class="page-header theme-bg-dark py-5 text-center position-relative">
    <div class="theme-bg-shapes-right"></div>
    <div class="theme-bg-shapes-left"></div>
    <div class="container py-5">
        <small class="text-white opacity-75">PHP Framework | for LAMP Stack</small>
        <h1 class="page-heading single-col-max mx-auto">Draft website with Arshwell</h1>
        <div class="page-intro single-col-max mx-auto">start your app using this draft</div>
    </div>
</div>

<section class="text-center py-5 position-relative">
    <div class="container py-5">
        <h4 class="mb-2 mb-3">Do you wanna learn how to use PHP frameworks?</h4>
        <div class="section-intro mb-3 single-col-max mx-auto">
            Come with us to the very low-priced online workshops.
        </div>
        <div class="pt-3 text-center">
            <a class="btn btn-dark" href="https://www.instagram.com/arshavinel/" target="_blank">
                Book a seat
                <i class="fas fa-arrow-alt-circle-right ml-2"></i>
            </a>
        </div>
    </div>
</section>
