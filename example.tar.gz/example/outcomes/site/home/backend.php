<?php

use Arshwell\Monolith\Meta;

Meta::set(
    'title',
    "My Project | Arshwell " . \Arshwell\Monolith\DevTool\DevToolData::ArshwellVersion()
);
Meta::set('description',	"I will make a stunning website.");
Meta::set('keywords',		"project, home, stunning");
