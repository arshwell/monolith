<div class="container text-center py-5">
    <h1>404</h1>
</div>
