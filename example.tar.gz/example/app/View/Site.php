<?php

namespace MyTeam\MyProject\View;

use Arshwell\Monolith\Table\TableView;

use MyTeam\MyProject\Language\LangSite;

class Site extends TableView {
    const TABLE         = 'views_site';
    const PRIMARY_KEY   = 'id_view';

    const TRANSLATOR    = LangSite::class;
}
