<?php

namespace MyTeam\MyProject\Language;

use Arshwell\Monolith\Language;

class LangSite extends Language {
    const PAGINATION    = "p-([1-9]\\d*)";
    const LANGUAGES     = array('en');
}
