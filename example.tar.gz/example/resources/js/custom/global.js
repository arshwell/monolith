/**
 * This file is included in all pages by layouts/utils.layout.json
 *
 * Put here the JS code you want to run in all pages.
 */

// open browser console, to convince yourself that this file is executed :D
console.log('Code executed from resources/js/custom/global.js');
