<?php

/**
 * PHP files from gates/ run at every request.
 *
 * You can restrict access or redirect the user as you like.
 */
