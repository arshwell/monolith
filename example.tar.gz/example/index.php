<?php

/*
|--------------------------------------------------------------------------
| Run Arshwell Framework
|--------------------------------------------------------------------------
|
| Used for web requests towards pages.
| All requests come here thanks to the .htaccess file.
|
| Excepting uploads/files/ requests which go to download.php,
| thanks to the uploads/files/.htaccess file.
|
*/

require("vendor/arshwell/monolith/bootstrap/index.php");
